package com.archit;

public interface Shape {

	int getArea();
	
	double getPerimeter();
	
}
